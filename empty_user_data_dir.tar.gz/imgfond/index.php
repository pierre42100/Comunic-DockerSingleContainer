<?php
	//Script de s�curit�.
	//Ne pas supprimer
	header('location: ../index.php');
?>